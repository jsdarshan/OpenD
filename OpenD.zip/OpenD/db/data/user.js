export default [
  {
    username: 'admin',
    email: 'admin@mail.com',
    password: 'admin123',
    passwordConfirmation: 'admin123'
  },
  {
    username: 'harsha',
    email: 'harsha@mail.com',
    password: 'pass321',
    passwordConfirmation: 'pass321'
  },
  {
    username: 'Darshan JS',
    email: 'darshajs2003@mail.com',
    password: 'pass322',
    passwordConfirmation: 'pass322'
  }
]