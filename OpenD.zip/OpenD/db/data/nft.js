export default [
  {
    name: 'BitMonkey',
    image: 'https://i.redd.it/xjbfb3hybli71.png',
    category: 'Cards'
  },
  {
    name: 'theCat',
    image: 'https://lh3.googleusercontent.com/DPytepoM9ZEGiLbq_9uo7rk3mCfpV8E3JgX-YtE25NjmONRNUKmd4VSY-_shzcGDDuOGq0rxyDcCWVHYsfKDBHJCN_7e8b67eYMo3g=s0',
    category: 'Collectibles'
  },
  {
    name: 'Bored FungleHeadz',
    image: 'https://lh3.googleusercontent.com/ljZg3igt0LiHfAsJ8tQhc5EL2TQa9u80Z13RcEJIMPl6JWOYqBNyrnHLDLAFUyngdjEdFqzc3iTls0BWJJO82cELo5scBspM1Sn2mQ=w600',
    category: 'Art'
  },
  {
    name: 'Crypto Heroe on Mars',
    image: 'https://lh3.googleusercontent.com/zm5apJVmz2qLkwBsUfd4ZYBuyatp3SDvWwZVQyj2waG2OKNjFbGfWkM9ohVPgF8w_G0I0oJj6rxOM4D2WqEgAl9GigAbrAhadLAL=w600',
    category: 'Art'
  },
  {
    name: 'Touch Down',
    image: 'https://lh3.googleusercontent.com/nc6vZc9-CJ-cKYNEoTiQf4YxdMRZptzqpnDBSgMYJmeexZzpu7Uu6672oxrke0yG3FMBHOL_zG5vyfZuOPmYzXqjKgQdQxQRoLT3=w600',
    category: 'Sports'
  },
  {
    name: 'Emerald Crowns',
    image: 'https://lh3.googleusercontent.com/QLlVIOYZkYn-3P4hVA178hYjlpVs0vD2kNKD0b4_C4W71AsORSHxzIblkOSyHnTPRVG8U8qmSo42Xvd7Dw36HXgjsUP29waOOzFZhA=w600',
    category: 'Sports'
  },
  {
    name: 'Ghost Mountain',
    image: 'https://lh3.googleusercontent.com/tKxvVgSiAksEBDOtSviikX4L1vlQfZDNeCyFSpCs2lVaKUsQPFagJhKj1xVIGzybCgWkyBBeEjnEasYLrsXXW6eRUNv8hMNZqfC9hA=w600',
    category: 'Sports'
  },
  {
    name: 'Gen Z Takeover',
    image: 'https://lh3.googleusercontent.com/5ejC_Q7ba3eUL1cBQqpAEgznNm6ZJ8KWGdu28xGKqkmjYSoNLWwx0-rSAvIbuSMwd6OqjRbAhV7s29QdokeQ8mM7tGJoIkoM35ziPg=w600',
    category: 'Sports'
  },
  {
    name: 'Pepalisa Rare',
    image: 'https://lh3.googleusercontent.com/WBDA82ODRDUqz4EVlqPuTsNcoiCYHpy2_fvUZHcNYPL1GQapQJAsTrHu_MmXFp1mRly-uwCH0wOR3i7TFzWtMyeZz--JzsFUZbn29Q=w600',
    category: 'Utility'
  },
  {
    name: 'Guatemala Nation Ownership',
    image: 'https://lh3.googleusercontent.com/5AgeO-ebaSbMzVl0qQBER9ZgCV5Rq51oeZW-NxFV5PPqnpa7CvQyHPSyhqOqWn3qzOQu9LAhs7TSwnCHNRDeV8_N_3zTElUnvhZA=w600',
    category: 'Virtual Worlds'
  },
  {
    name: 'Bulgaria Nation Ownership',
    image: 'https://lh3.googleusercontent.com/W95HjLnEQbQ6e2RvgRj1GMj1z1BdSmGnw4EkEGubaks1fMlGr83gQb-nWROT0dSp2hQOcfwJrVpxS4YUIm8NZXdNi2hV3BGtaUXrdA=w600',
    category: 'Virtual Worlds'
  }, 
  {
    name: 'GoonCat',
    image: 'https://lh3.googleusercontent.com/eGEwLmXvIRaJdv3FhUI5xp7heIj7N9JTStrH7aZ-1MGkq8rSTBN983acwweRFUcBlD0XjCq1T428lBkLxOzae5-5TZ-zJeVHXYdKY5I=w600',
    category: 'Virtual Worlds'
  },
  {
    name: 'REVV Blur',
    image: 'https://lh3.googleusercontent.com/NBWtbqrkLIHeWDxf0of85hlDGZESwXDB1UBZzAEwR9UBOjhF42HSGLJ7J-spqiYprIA8WvnsrylZsQMLOqYW8l4xUME-0gPWiBhT0Q=w600',
    category: 'Sports'
  },
  {
    name: 'REVV Aspire',
    image: 'https://lh3.googleusercontent.com/LA27BRv_RMC691TKff2P86XAj1DB4MDvv0u7cpUXsFk6haYZriEwqeWifi8fsHlds0d9k-_d7LTp-AcFtqe8Gw0muq7TYefZo3ozRw=w600',
    category: 'Sports'
  },
  {
    name: 'Byteosaurus',
    image: 'https://lh3.googleusercontent.com/-6hB7nf65kD5zh4zuOKtFhvIxa6fd0wkmTHfCwPclFW67dGieHcKFvBxuaq6eakrbkeeZXp7KinCq1OTY6nu7MyKFY23IG7m2vjY=w600',
    category: 'Art'
  },
  {
    name: 'Skullx',
    image: 'https://lh3.googleusercontent.com/dp1gLyWgaZVCxYPEickcAoGEMOcX1wU6T1pfPy-wdcIGBJx3EutFjhEhNmEt3e1iTzWmZNbc4R7-IGDZdwJADJNltpiN5TX2WQBYuw=w600'
  },
  {
    name: 'Creepy Cream',
    image: 'https://lh3.googleusercontent.com/fceO8M9E3qCuS0W4UThCINeLOZ8DrE1w_dciLvXKeuq0kEGQL_9232dHjxa2Y0X138_IdAkD302JvgMwCHgqRuOKOEtzxAOhDVTG=w600',
    category: 'Utility'
  },
  {
    name: 'PEKMAN, Card 30',
    image: 'https://lh3.googleusercontent.com/gc5ig4FrvVGkV8nbIB-tDc0Putp3bnp318OFcQOBoTDIQK-gblhabZnfnUmZtAZ_9__mUYZz45lc0nc4j9aUHnkz6g5fpefSARwrjQ=w600',
    category: 'Utility'
  },
  {
    name: 'Chicken 31764',
    image: 'https://lh3.googleusercontent.com/068KOgQN55njS6MIULXZki_PQa4gXBcwzd9epIgMlSPU2plO9h_C-Z3bS9_z2xa1H5O8zhC3zr9BfpUfcXdD1Dg6aF3fSHxBnSDM9rA=w600',
    category: 'Utility'
  },
  {
    name: 'The Terminator',
    image: 'https://lh3.googleusercontent.com/Kbts_7WluP3XEPp25jaYQER-dwLUxl3qH1gF4tb2Ds210ZWHGmdA4v8xKmqETXHY_7vr9KrettVGk-YVIRV6PcBB30HoVdGRwc3t=w600',
    category: 'Utility'
  },
  {
    name: 'PixelBeast',
    image: 'https://lh3.googleusercontent.com/nwtfqREY8ZogzrwR8OYd3v0R83270l1_Yo6I1dntVwSyOeNS1utKdYqAFPMZE_iynY1mQC3lDsH6_fySDIsjZ7NZdQVa4ZDgIck7mg=w600',
    category: 'Utility'
  },
  {
    name: 'Blackout Drinking',
    image: 'https://lh3.googleusercontent.com/VEhWk7wZv5s9jMxXHUi5O4K6m07XfrU8HEpuXWrkM0phDHtuBOVfbCP6x3-UE3B5PpHcAt26G-14gpTAHlkU45qFswYXHab0j84anw=w600',
    category: 'Sports'
  },
  {
    name: 'BOONJI',
    image: 'https://lh3.googleusercontent.com/34ns4iZnuOEgwHrCPrKkLBlfKRfZ0uHLvq7sv1DueANdzRMc0CBdHe9jdFnZvUKUfRHiqtlpTe3VBtqfsqNbsLoWtqp_PknseGy-D4M=w600',
    category: 'Art'
  },
  {
    name: 'Goon Cats',
    image: 'https://lh3.googleusercontent.com/G9gJMlyeq282cZ9yguEuodzJPl7dLSThXvIiRr1WHO-7CGb2kPJFwfus0rsjcLz35O_9RTbnY03qj_ysr9QAl2_XFwSgGLjxEz6Wsg=w600',   
    category: 'Collectibles'
  },
  {
    name: 'BeezerBear',
    image: 'https://lh3.googleusercontent.com/Kk7_TypYGM3hWzNfi94JRxDY_biyol5ElaqkygiXLmLbpkZhZq1hqkDUBOzdyEXLgHmAFKCNNXSY4ue8m4p9iIJ7dFuw4NTwEyEo0w=s0',
    category: 'Collectibles'
  },
  {
    name: 'MonaMusk',
    image: 'https://lh3.googleusercontent.com/GjzgYhThXYSjWSIu3ZrNJPiiHC7fpGUN2FYYuYGzc1uciiHx4vexMvxSW-7LNTyAANJZ2iOIMYr8mhNouzZG6Xc62D4OLofX3iLditI=w600',
    category: 'Card'
  },
  {
    name: 'Crypto Hero',
    image: 'https://lh3.googleusercontent.com/UzagG9Zr7-RJn9bt1rfQHNLTwH9Urxwkwv7QWlKqblkQqncH3EYMVj7cK1stcGc4cnNl7T-eyK20F8Fs8XG43qeYmy60tsZ2Ft8ZOg=w600',
    category: 'Virtual Worlds'
  },
  {
    name: 'Shiba',
    image: 'https://64.media.tumblr.com/16a1bc1dc7ce99717e8efac90dcfd37f/fb509ffcb071383c-69/s540x810/78516e407950983af8cb6e9f841343cbcb5bb8ee.gifv',
    category: 'Virtual Worlds'
  },
  {
    name: 'Bored Ape',
    image: 'https://lh3.googleusercontent.com/yJ0crgQo01cM8yMl-b71nbDxiR8GO0aHIi4v0v5RBxyQjqcedb1dg6OSc3qS3OVT9c5Wris5dcFc215VONmUA1IQBZ8xsHVzClduQcY=w600',
    category: 'Collectibles'
  },
  {
    name: 'WeWorld',
    image: 'https://lh3.googleusercontent.com/dex93jCbApk6Xe8dzvt3HavH1c0eRV099hDkXoK2UnOmaA__Qg00PnLwMDKnBcfwo4TkYCI-T953r_wS_qXQbcsUY-FzZYuz5eyLo8I=w600',
    category: 'Virtual Worlds'
  },
  {
    name: 'Smokester',
    image: '  https://lh3.googleusercontent.com/UFfo7KXKp-S0Gc85FcJs_cZhWXorlvDuwyfVyHjLPwJz27jV57wXy1i92hHh8QB3qmUJpY4HdPQvnWVP3-O3mxN6bkmhsiyt9Pyx=w600',
    category: 'Collectibles'
  },
  {
    name: 'SkaterTony',
    image: 'https://lh3.googleusercontent.com/uyocg4pYMp3AjjMKkf5aMb3U5Tk_xFm6DuiCeG8Iod7UqMNpzrUA1TrR960wDWMNlKim3a9JL7MvPCA9LbWv_uDcQQlL9NNhyq_Nf3k=w600',
    category: 'Art'
  },
  {
    name: 'UltraPunk',
    image: 'https://lh3.googleusercontent.com/TqlW5vmutG_qXrvHbjcdK7ATrzbbV79HQnHxDq6Jh9-r_o8MBcYlm4EfcRW9fMr6bSEzEyByDDX94w4dBb73qcUIwB9ZOSRz72vLrQ=w600',
    category: 'Collectibles'
  },
  {
    name: 'Ethermon',
    image: 'https://lh3.googleusercontent.com/u485S1UVF8xufP54ZtynanKbb0KnPllKJQDjg8JESNS7tRYhMEMXkS2Ss7PcxVlh5PT9VlhYsYIJvGMIdy3PcfFazsfGxjCarTCW52U=w600',
    category: 'Collectibles'
  },
  {
    name: 'Wall Street Block of Gold',
    image: 'https://lh3.googleusercontent.com/PklSk2bNxkSJdQdG6rfbVoCsLE7xxeNkkZQEMLZerC2SgXN_F7MqWl6rQXA1KSbH95FSxWnsqKwnlxb0Z-i5n6DbvWJJsz8_ILms5Q=w600',
    category: 'Utility'
  },
  {
    name: 'Rabbitar',
    image: 'https://lh3.googleusercontent.com/GqFhBi6qaFNfEs6yVt3rUnWCIacLQkWlg8dEChWpkv8NGluJ5Tib3zzBBHjdyb7HmE2MScfROLzX8D-liEd9gEsvEduJMY9w9cyF6g=w600',
    category: 'Art'
  },
  {
    name: 'MetaFreaks Insert',
    image: 'https://lh3.googleusercontent.com/2PmNoBDPPvB5ASF786Ehb7aJKpQNGjRP3ZGYhzOcZF9pM_V-ehFmQdv41Q6t2oO-0lk9pNX3nWF5DIYTjLYMudoxkf2NN5-5eEPR=w6000',
    category: 'Card'
  },
  {
    name: 'Knights of Degen',
    image: 'https://lh3.googleusercontent.com/aVmWawCGIo3-ByJ19E50e2zWo0lCspvaMVFUJPTR88T4gQbelJq5PvWqePnMXkZoNOmpISO9Ft2yhYEnybgafGHjRsRU_RqeBmzQmg=w600',
    category: 'Sport'
  },
  {
    name: 'SportsIcon Lion',
    image: 'https://lh3.googleusercontent.com/fuJXiL_bS4UjbL7-rY9zwnKrTWrYmqvslTh1CJw2ua96Mu3_3RDHwksX00_DYWxmic3k2vajgEKCwRvLGR_XTHyTXfvLucmKQ2PunA=w600',
    category: 'Sport'
  },
  {
    name: 'ArtWars Orange',
    image: 'https://lh3.googleusercontent.com/DO9gf65ThMykUnPyErREW2nMUfOlLLZiJ6BfFObOd6iJoXyRz2aUUDnXM-eMlvEGcowzsG737Pq03v3wek2KMiyysPTq976wK6SF7w=w600',
    category: 'Art'
  }

]     